/// API Keys Configuration
/// 
/// IMPORTANT: This file contains sensitive API keys and should NOT be committed to version control.
/// Add this file to .gitignore
library;

class ApiKeys {
  // ImgBB API Key
  // Get yours at: https://api.imgbb.com/
  static const String imgbbApiKey = 'c2ca0d8f346fb8c2bad8caa88d061ce3';

  // Cloudinary Configuration
  // Get yours at: https://cloudinary.com
  static const String cloudinaryCloudName = 'dc7td9rfj';
  static const String cloudinaryUploadPreset = 'report_videos';
}
